CoderPlace Core - WordPress Plugin for the CoderPlace Theme

== Description ==
This is core plugin required by the CoderPlace Theme for the core features of theme.
